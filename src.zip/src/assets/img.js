import us from './img/us2.png';
import pacs from './img/pacs2.png';
import vitrea from './img/vitrea2.png';
import skincare from './img/skincare.jpg'
import it from './img/it.png'


export const allimages = [
  us,
  pacs,
  vitrea,
  skincare,
  it
];
